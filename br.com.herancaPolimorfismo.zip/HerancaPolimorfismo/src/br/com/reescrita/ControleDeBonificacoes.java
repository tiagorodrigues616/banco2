package br.com.reescrita;

public class ControleDeBonificacoes {
	private double totalDeBonificacoes = 0;
	
	// chamar um método dentro de outro método
	public void registra(Funcionario funcionario) {
		this.totalDeBonificacoes = totalDeBonificacoes + funcionario.getBonificacao();
	}
	
	public double getTotalDeBonificacoes() {
		return this.totalDeBonificacoes;
	}

}
