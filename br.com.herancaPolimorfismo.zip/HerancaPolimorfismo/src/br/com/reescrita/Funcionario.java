package br.com.reescrita;

public class Funcionario {
	// Atributos
	protected String nome;
	protected String cpf;
	protected double salario;

	// outros métodos
	public double getBonificacao() {
		return this.salario * 0.10;
	}
	
	// Métodos construtores
	public void setNome(String nome) {
		this.nome = nome;
	}
	
	public String getNome() {
		return nome;
	}
	
	public void setSalario(double salario) {
		this.salario = salario;
		
	}
	
	public double getSalario() {
		return salario;
	}
	
}
