package br.com.reescrita;

public class TestaGerente {
	public static void main(String[] args) {
	
		//Gerente gerente = new Gerente();
		//Funcionario funcionario = gerente;
		//gerente.setNome("João da Silva");
		//gerente.setSenha(4321);
		
		ControleDeBonificacoes controle = new ControleDeBonificacoes();
		
		Gerente funcionario1 = new Gerente();
		funcionario1.setSalario(5000.0);
		controle.registra(funcionario1);
		
		System.out.println(controle.getTotalDeBonificacoes());
		
		Funcionario funcionario2 = new Funcionario();
		funcionario2.setSalario(1000.0);
		controle.registra(funcionario2);
		
		System.out.println(controle.getTotalDeBonificacoes());
		
		// System.out.println("Usuario: "+ gerente.getSenha() +"\nUser: " + gerente.getNome() );
		// System.out.println(funcionario.getBonificacao());
		
		
		
		
		
		
		
	}

}
