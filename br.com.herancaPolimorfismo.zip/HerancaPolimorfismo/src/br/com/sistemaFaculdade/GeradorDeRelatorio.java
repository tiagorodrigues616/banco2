package br.com.sistemaFaculdade;

public class GeradorDeRelatorio {
	
	public void adiciona (EmpregadoDaFaculdade f) {
		System.out.println(f.getInfo());
		System.out.println(f.getGastos());
	}

}
