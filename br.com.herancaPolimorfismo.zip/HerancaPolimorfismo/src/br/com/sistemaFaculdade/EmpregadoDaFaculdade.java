package br.com.sistemaFaculdade;

public class EmpregadoDaFaculdade {
	private String nome;
	private double salario;
	
	// Métodos 
	public double getGastos() {
		return this.salario;
	}
	
	public String getInfo() {
		return "nome: " + this.nome + " com salário " + this.salario;
	}
	
	// métodos get e set
	
	public void setSalario(double salario) {
		this.salario = salario;
	}

	public double getSalario() {
		return salario;
	} 
	
	public void setNome(String nome) {
		this.nome = nome;
	}
	
	public String getNome() {
		return nome;
	}
	

}
