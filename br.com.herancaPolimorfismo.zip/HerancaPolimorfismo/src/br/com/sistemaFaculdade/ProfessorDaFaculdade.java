package br.com.sistemaFaculdade;

public class ProfessorDaFaculdade extends EmpregadoDaFaculdade {
	private int horasDeAula;
	
	public double getGastos() {
		return this.getSalario() + this.horasDeAula * 10;
	}
	
	public String getInfo() {
		String informacaoBasica = super.getInfo();
		String informacao = informacaoBasica + " horas de aula: " + this.horasDeAula;
		return informacao;
	}
	
	// métodos get e set
	
	public void setHorasDeAula(int horasDeAula) {
		this.horasDeAula = horasDeAula;
	}
	
	public int getHorasDeAula() {
		return horasDeAula;
	}

}
