package br.com.sistemaFaculdade;

public class ReitorDaFaculdade extends EmpregadoDaFaculdade {
	
	public String getInfo() {
		return super.getInfo() + " e ele é um reitor";
	}

}
