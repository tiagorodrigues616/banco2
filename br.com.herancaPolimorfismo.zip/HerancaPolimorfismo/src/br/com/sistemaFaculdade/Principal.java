package br.com.sistemaFaculdade;

public class Principal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		EmpregadoDaFaculdade empregado = new EmpregadoDaFaculdade();
		GeradorDeRelatorio relatorio = new GeradorDeRelatorio();
		ReitorDaFaculdade reitor = new ReitorDaFaculdade();
		
		empregado.setNome("Rafael");
		empregado.setSalario(2000.00);
		reitor.getInfo();
		
		relatorio.adiciona(empregado);

	}

}
